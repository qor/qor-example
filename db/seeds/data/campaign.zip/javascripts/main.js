document.addEventListener('DOMContentLoaded', function() {
  document.getElementsByTagName("h1")[0].style.color = "green";
}, false);
